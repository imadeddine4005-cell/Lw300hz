# lw300hz — Full Android Phone Client

A dark computer-style Android POS + inventory + customers/credit + analytics + project studio.

## Included
- Offline-first SQLite data
- POS counter sale with categories, search, cart, discount, cash/card/credit, partial credit payment
- Receipt/bon after checkout
- Customers, balances, payments, purchase history
- Inventory, stock in/out, low-stock status, cost/price/profit
- Dashboard and reports
- Four distinct project modes: Electrical, Placo/Drywall, Plumbing, Paint
- Finger sketch canvas + dimensions + material calculator
- Interactive OpenGL ES 3D scene with different rendering per project type
- Internal LAN server switch and port/token settings (server endpoint implementation is intentionally lightweight and can be expanded for tablet sync)

## Build
Open the project root in Android Studio or a compatible Gradle Android IDE, or use the included GitHub Actions workflow.
The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.
