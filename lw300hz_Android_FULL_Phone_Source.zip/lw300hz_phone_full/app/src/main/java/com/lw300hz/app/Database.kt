package com.lw300hz.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

data class Product(val id:Long,val name:String,val category:String,val sku:String,val price:Double,val cost:Double,val stock:Double,val unit:String,val minStock:Double)
data class Customer(val id:Long,val name:String,val phone:String,val balance:Double)
data class CartItem(val product:Product,var qty:Double)

data class SaleResult(val invoice:String,val total:Double,val paid:Double,val remaining:Double)

class DB(ctx: Context): SQLiteOpenHelper(ctx,"lw300hz.db",null,1) {
    override fun onCreate(d:SQLiteDatabase) {
        d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE)")
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,sku TEXT UNIQUE,price REAL,cost REAL,stock REAL,unit TEXT,min_stock REAL)")
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,balance REAL DEFAULT 0)")
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice TEXT UNIQUE,customer_id INTEGER,total REAL,discount REAL,payment TEXT,paid REAL,remaining REAL,created_at TEXT)")
        d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,product_id INTEGER,qty REAL,price REAL,cost REAL)")
        d.execSQL("CREATE TABLE stock_moves(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,qty REAL,type TEXT,note TEXT,created_at TEXT)")
        d.execSQL("CREATE TABLE projects(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,type TEXT,width REAL,length REAL,height REAL,sketch TEXT,created_at TEXT,updated_at TEXT)")
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)")
        seed(d)
    }
    override fun onUpgrade(d:SQLiteDatabase,old:Int,new:Int){ d.execSQL("DROP TABLE IF EXISTS sale_items");d.execSQL("DROP TABLE IF EXISTS sales");d.execSQL("DROP TABLE IF EXISTS stock_moves");d.execSQL("DROP TABLE IF EXISTS products");d.execSQL("DROP TABLE IF EXISTS categories");d.execSQL("DROP TABLE IF EXISTS customers");d.execSQL("DROP TABLE IF EXISTS projects");d.execSQL("DROP TABLE IF EXISTS settings");onCreate(d) }
    private fun seed(d:SQLiteDatabase){
        val cats=listOf("Electrical / كهرباء","Construction / مواد بناء","Pipes & Plumbing / أنابيب","Placo / بلاكو","Paint / طلاء","Hardware / خردوات","Decor / ديكور","Tools / أدوات")
        cats.forEach{ val v=ContentValues();v.put("name",it);d.insert("categories",null,v) }
        val ps=listOf(
            arrayOf("LED Panel 24W","Electrical / كهرباء","EL-LED-24",850.0,600.0,30.0,"pcs",5.0),arrayOf("Cable 2x1.5","Electrical / كهرباء","EL-CAB-15",95.0,70.0,180.0,"m",30.0),arrayOf("Socket 16A","Electrical / كهرباء","EL-SOC-16",180.0,120.0,60.0,"pcs",10.0),arrayOf("Switch 1G","Electrical / كهرباء","EL-SW-1",160.0,100.0,55.0,"pcs",10.0),
            arrayOf("Cement 50kg","Construction / مواد بناء","BL-CEM-50",750.0,600.0,120.0,"bag",20.0),arrayOf("Sand","Construction / مواد بناء","BL-SAND",2500.0,1800.0,25.0,"m3",4.0),arrayOf("Plasterboard 120x250","Placo / بلاكو","DR-125",900.0,700.0,70.0,"sheet",10.0),arrayOf("Metal Stud 3m","Placo / بلاكو","DR-STUD-3",320.0,240.0,140.0,"pcs",20.0),arrayOf("Track 3m","Placo / بلاكو","DR-TRACK-3",300.0,220.0,100.0,"pcs",20.0),arrayOf("Drywall Screw","Placo / بلاكو","DR-SCR",12.0,7.0,1200.0,"box",100.0),
            arrayOf("PPR Pipe 20mm","Pipes & Plumbing / أنابيب","PL-PPR20",190.0,140.0,200.0,"m",30.0),arrayOf("PPR Elbow 20mm","Pipes & Plumbing / أنابيب","PL-EL20",45.0,28.0,120.0,"pcs",20.0),arrayOf("Ball Valve 20mm","Pipes & Plumbing / أنابيب","PL-V20",420.0,300.0,35.0,"pcs",5.0),
            arrayOf("Interior Paint 10L","Paint / طلاء","PT-10",3200.0,2400.0,40.0,"bucket",5.0),arrayOf("Primer 10L","Paint / طلاء","PT-PR-10",2500.0,1800.0,25.0,"bucket",5.0),arrayOf("Roller 25cm","Paint / طلاء","PT-ROL",450.0,300.0,45.0,"pcs",5.0),arrayOf("Masking Tape","Paint / طلاء","PT-TAPE",180.0,110.0,60.0,"pcs",10.0)
        )
        ps.forEach{a->val v=ContentValues();v.put("name",a[0] as String);v.put("category",a[1] as String);v.put("sku",a[2] as String);v.put("price",a[3] as Double);v.put("cost",a[4] as Double);v.put("stock",a[5] as Double);v.put("unit",a[6] as String);v.put("min_stock",a[7] as Double);d.insert("products",null,v)}
        listOf(arrayOf("Walk-in Customer",""),arrayOf("Ahmed","0550000000"),arrayOf("Client A","0660000000")).forEach{a->val v=ContentValues();v.put("name",a[0]);v.put("phone",a[1]);d.insert("customers",null,v)}
        val s=ContentValues();s.put("k","lan_enabled");s.put("v","0");d.insert("settings",null,s);val p=ContentValues();p.put("k","lan_port");p.put("v","8765");d.insert("settings",null,p);val t=ContentValues();t.put("k","lan_token");t.put("v","lw300hz");d.insert("settings",null,t)
    }
    fun products(search:String="",category:String=""):List<Product>{val out=mutableListOf<Product>();val c=readableDatabase.query("products",null,"name LIKE ? AND category LIKE ?",arrayOf("%$search%","%$category%"),null,null,"name ASC");c.use{while(it.moveToNext())out.add(Product(it.getLong(it.getColumnIndexOrThrow("id")),it.getString(it.getColumnIndexOrThrow("name")),it.getString(it.getColumnIndexOrThrow("category")),it.getString(it.getColumnIndexOrThrow("sku")),it.getDouble(it.getColumnIndexOrThrow("price")),it.getDouble(it.getColumnIndexOrThrow("cost")),it.getDouble(it.getColumnIndexOrThrow("stock")),it.getString(it.getColumnIndexOrThrow("unit")),it.getDouble(it.getColumnIndexOrThrow("min_stock"))))};return out}
    fun categories():List<String>{val l=mutableListOf<String>();readableDatabase.rawQuery("SELECT name FROM categories ORDER BY id",null).use{while(it.moveToNext())l.add(it.getString(0))};return l}
    fun customers():List<Customer>{val l=mutableListOf<Customer>();readableDatabase.rawQuery("SELECT id,name,phone,balance FROM customers ORDER BY name",null).use{while(it.moveToNext())l.add(Customer(it.getLong(0),it.getString(1),it.getString(2),it.getDouble(3)))};return l}
    fun checkout(cart:List<CartItem>,customerId:Long,total:Double,discount:Double,payment:String,paid:Double):SaleResult{val d=writableDatabase;d.beginTransaction();try{val invoice="LW-${System.currentTimeMillis()}";val rem=(total-paid).coerceAtLeast(0.0);val v=ContentValues();v.put("invoice",invoice);v.put("customer_id",customerId);v.put("total",total);v.put("discount",discount);v.put("payment",payment);v.put("paid",paid);v.put("remaining",rem);v.put("created_at",now());val sid=d.insertOrThrow("sales",null,v);cart.forEach{item->val si=ContentValues();si.put("sale_id",sid);si.put("product_id",item.product.id);si.put("qty",item.qty);si.put("price",item.product.price);si.put("cost",item.product.cost);d.insert("sale_items",null,si);val up=ContentValues();up.put("stock",item.product.stock-item.qty);d.update("products",up,"id=?",arrayOf(item.product.id.toString()));val mv=ContentValues();mv.put("product_id",item.product.id);mv.put("qty",-item.qty);mv.put("type","SALE");mv.put("note",invoice);mv.put("created_at",now());d.insert("stock_moves",null,mv)};if(rem>0){val u=ContentValues();u.put("balance","balance + $rem");d.execSQL("UPDATE customers SET balance = balance + ? WHERE id=?",arrayOf(rem,customerId))};d.setTransactionSuccessful();return SaleResult(invoice,total,paid,rem)}finally{d.endTransaction()}}
    fun payDebt(id:Long,amount:Double){writableDatabase.execSQL("UPDATE customers SET balance=MAX(balance-?,0) WHERE id=?",arrayOf(amount,id))}
    fun stockMove(id:Long,qty:Double,incoming:Boolean,note:String){val d=writableDatabase;d.execSQL("UPDATE products SET stock=stock+? WHERE id=?",arrayOf(if(incoming)qty else -qty,id));val v=ContentValues();v.put("product_id",id);v.put("qty",if(incoming)qty else -qty);v.put("type",if(incoming)"IN" else "OUT");v.put("note",note);v.put("created_at",now());d.insert("stock_moves",null,v)}
    fun stats():Map<String,Double>{val d=readableDatabase;val sales=d.rawQuery("SELECT COALESCE(SUM(total),0) FROM sales WHERE date(created_at)=date('now','localtime')",null).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val profit=d.rawQuery("SELECT COALESCE(SUM((si.price-si.cost)*si.qty),0) FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)=date('now','localtime')",null).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val debt=d.rawQuery("SELECT COALESCE(SUM(balance),0) FROM customers",null).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val low=d.rawQuery("SELECT COUNT(*) FROM products WHERE stock<=min_stock",null).use{if(it.moveToFirst())it.getDouble(0) else 0.0};return mapOf("sales" to sales,"profit" to profit,"debt" to debt,"low" to low)}
    fun setting(k:String,def:String="")=readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0) else def}
    fun setSetting(k:String,v:String){val c=ContentValues();c.put("k",k);c.put("v",v);writableDatabase.insertWithOnConflict("settings",null,c,SQLiteDatabase.CONFLICT_REPLACE)}
    fun saveProject(name:String,type:String,w:Double,l:Double,h:Double,sketch:String){val v=ContentValues();v.put("name",name);v.put("type",type);v.put("width",w);v.put("length",l);v.put("height",h);v.put("sketch",sketch);v.put("created_at",now());v.put("updated_at",now());writableDatabase.insert("projects",null,v)}
}
