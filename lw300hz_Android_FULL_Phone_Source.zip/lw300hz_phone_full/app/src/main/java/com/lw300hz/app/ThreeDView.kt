package com.lw300hz.app

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import kotlin.math.cos
import kotlin.math.sin
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ThreeDView(context: Context): GLSurfaceView(context) {
    private val renderer=SceneRenderer()
    init { setEGLContextClientVersion(2);setRenderer(renderer);renderMode=RENDERMODE_CONTINUOUSLY }
    fun setType(type:String){renderer.type=type}
    override fun onTouchEvent(e:MotionEvent):Boolean{when(e.actionMasked){MotionEvent.ACTION_MOVE->{if(e.pointerCount>0){renderer.yaw += (e.x-e.px)*0.7f;renderer.pitch=(renderer.pitch+(e.y-e.py)*0.4f).coerceIn(-70f,70f)};renderer.px=e.x;renderer.py=e.y};MotionEvent.ACTION_DOWN->{renderer.px=e.x;renderer.py=e.y}};return true}
}

private class SceneRenderer:GLSurfaceView.Renderer {
    var type="drywall";var yaw=35f;var pitch=22f;var zoom=1f;var px=0f;var py=0f
    private val mvp=FloatArray(16);private val proj=FloatArray(16);private val view=FloatArray(16);private val model=FloatArray(16)
    private lateinit var cube:Cube
    override fun onSurfaceCreated(gl:GL10?,c:EGLConfig?){GLES20.glClearColor(0.025f,0.06f,0.10f,1f);cube=Cube()}
    override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int){GLES20.glViewport(0,0,w,h);val r=w.toFloat()/h.coerceAtLeast(1);Matrix.frustumM(proj,0,-r,r,-1f,1f,2f,100f)}
    override fun onDrawFrame(gl:GL10?){GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT);GLES20.glEnable(GLES20.GL_DEPTH_TEST);Matrix.setLookAtM(view,0,0f,0f,12f,0f,0f,0f,0f,1f,0f);Matrix.setIdentityM(model,0);Matrix.rotateM(model,0,pitch,1f,0f,0f);Matrix.rotateM(model,0,yaw,0f,1f,0f);Matrix.scaleM(model,0,zoom,zoom,zoom);Matrix.multiplyMM(mvp,0,view,0,model,0);Matrix.multiplyMM(mvp,0,proj,0,mvp,0);drawScene()}
    private fun drawScene(){when(type){"drywall"->{cube.box(mvp,-3f,-2f,0f,3f,2f,0.15f,0.15f);cube.box(mvp,-3f,-2f,0f,-2.85f,2f,3f,0.10f);cube.box(mvp,2.85f,-2f,0f,3f,2f,3f,0.10f);cube.box(mvp,-3f,-2f,2.85f,3f,2f,3f,0.10f);cube.box(mvp,-2.9f,-1.9f,2.95f,2.9f,1.9f,3.05f,0.10f)}
        "electrical"->{cube.box(mvp,-3f,-2f,0f,3f,2f,0.12f,0.15f);cube.box(mvp,-0.55f,-0.45f,0.1f,0.55f,0.45f,0.65f,0.2f);cube.line(mvp,0f,0.1f,0.65f,-2.4f,-1.5f,0.2f);cube.line(mvp,0f,0.1f,0.65f,2.4f,-1.5f,0.2f);cube.line(mvp,0f,0.1f,0.65f,2.4f,1.4f,0.2f);cube.line(mvp,0f,0.1f,0.65f,-2.4f,1.4f,0.2f)}
        "plumbing"->{cube.line(mvp,-2.7f,-1.5f,0.25f,2.4f,-1.5f,0.25f);cube.line(mvp,0f,-1.5f,0.25f,0f,1.4f,0.25f);cube.line(mvp,0f,1.4f,0.25f,2.2f,1.4f,0.25f);cube.box(mvp,1.3f,0.7f,0.1f,2.5f,1.8f,0.7f,0.12f)}
        "paint"->{cube.box(mvp,-3f,-2f,0f,3f,2f,0.12f,0.1f);cube.box(mvp,-3f,-2f,0.9f,3f,2f,1.0f,0.08f);cube.box(mvp,-3f,-2f,1.8f,3f,2f,1.9f,0.08f);cube.box(mvp,-3f,-2f,2.7f,3f,2f,2.8f,0.08f)}}}
}

private class Cube { private val vs=floatArrayOf(-1f,-1f,-1f,1f,-1f,-1f,1f,1f,-1f,-1f,1f,-1f,-1f,-1f,1f,1f,-1f,1f,1f,1f,1f,-1f,1f,1f);private val fs=intArrayOf(0,1,2,0,2,3,1,5,6,1,6,2,5,4,7,5,7,6,4,0,3,4,3,7,3,2,6,3,6,7,4,5,1,4,1,0);private val prog:Int;init{val v="attribute vec4 a;uniform mat4 m;void main(){gl_Position=m*a;}";val f="precision mediump float;uniform vec4 c;void main(){gl_FragColor=c;}";prog=GLES20.glCreateProgram().also{GLES20.glAttachShader(it,shader(GLES20.GL_VERTEX_SHADER,v));GLES20.glAttachShader(it,shader(GLES20.GL_FRAGMENT_SHADER,f));GLES20.glLinkProgram(it)}};private fun shader(t:Int,s:String)=GLES20.glCreateShader(t).also{GLES20.glShaderSource(it,s);GLES20.glCompileShader(it)}
    fun box(m:FloatArray,x1:Float,y1:Float,z1:Float,x2:Float,y2:Float,z2:Float,th:Float){draw(m,x1,y1,z1,x2,y2,z2,th)}
    fun line(m:FloatArray,x1:Float,y1:Float,z1:Float,x2:Float,y2:Float,z2:Float){val old=FloatArray(24);System.arraycopy(vs,0,old,0,24);val arr=floatArrayOf(x1,y1,z1,x2,y1,z1,x2,y2,z1,x1,y2,z1,x1,y1,z2,x2,y1,z2,x2,y2,z2,x1,y2,z2);drawRaw(m,arr,0.9f,0.7f,0.15f,1f)}
    private fun draw(m:FloatArray,x1:Float,y1:Float,z1:Float,x2:Float,y2:Float,z2:Float,th:Float){val arr=floatArrayOf(x1,y1,z1,x2,y1,z1,x2,y2,z1,x1,y2,z1,x1,y1,z2,x2,y1,z2,x2,y2,z2,x1,y2,z2);drawRaw(m,arr,0.1f,0.55f,1f,1f)}
    private fun drawRaw(m:FloatArray,arr:FloatArray,r:Float,g:Float,b:Float,a:Float){GLES20.glUseProgram(prog);val ab=GLES20.glGetAttribLocation(prog,"a");val mm=GLES20.glGetUniformLocation(prog,"m");val cc=GLES20.glGetUniformLocation(prog,"c");val bb=java.nio.ByteBuffer.allocateDirect(arr.size*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer();bb.put(arr).position(0);GLES20.glUniformMatrix4fv(mm,1,false,m,0);GLES20.glUniform4f(cc,r,g,b,a);GLES20.glEnableVertexAttribArray(ab);GLES20.glVertexAttribPointer(ab,3,GLES20.GL_FLOAT,false,12,bb);GLES20.glDrawElements(GLES20.GL_TRIANGLES,36,GLES20.GL_UNSIGNED_SHORT,java.nio.ByteBuffer.allocateDirect(72).order(java.nio.ByteOrder.nativeOrder()).asShortBuffer().also{it.put(fs.map{it.toShort()}.toShortArray()).position(0)});GLES20.glDisableVertexAttribArray(ab)}
}
